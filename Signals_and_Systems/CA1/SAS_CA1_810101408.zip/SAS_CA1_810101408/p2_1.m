p2=load('p2.mat')

figure;
plot(p2.t,p2.x)
xlabel('t') % the name of X-axis
ylabel('x') % the name of Y-axis
grid on % Add grid