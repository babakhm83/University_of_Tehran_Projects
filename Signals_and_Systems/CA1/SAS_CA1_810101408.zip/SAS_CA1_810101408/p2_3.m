p2=load('p2.mat')

figure;
plot(p2.x,p2.y,'.')
xlabel('x') % the name of X-axis
ylabel('y') % the name of Y-axis
grid on % Add grid