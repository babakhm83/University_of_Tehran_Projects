p2=load('p2.mat')

figure;
plot(p2.t,p2.y)
xlabel('t') % the name of X-axis
ylabel('y') % the name of Y-axis
grid on % Add grid