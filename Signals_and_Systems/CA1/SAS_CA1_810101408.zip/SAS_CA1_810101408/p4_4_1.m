[x fs]=audioread('x.wav');
p4_4(x,0.3)