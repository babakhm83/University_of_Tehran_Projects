[x fs]=audioread('x.wav');
p4_3(x,2)