[x fs]=audioread('audio.wav');
sound(x,fs)
fs